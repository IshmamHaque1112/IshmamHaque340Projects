#/bin/sh
clear 
g++ -pthread -o test IHaque_prj3_sect25_src.cpp
if [ -f "test" ]; then 
 ./test prj2inp1.txt 
 ./test prj2inp2.txt 
 rm test 
fi
