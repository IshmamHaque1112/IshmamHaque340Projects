//Ishmam Haque Tuesday Thursday class
//chmod u+x IHaque_prj3_sect25_src.cpp
//g++ -pthread -o test IHaque_prj3_sect25_src.cpp
//./test prj2inp1.txt
//./test prj2inp2.txt
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdlib.h>
int finddigit(int a){
 int copyofa=a;
 if(a==0) return 1;
 int digits=0;
 while(copyofa>0){
  digits++;
  copyofa=copyofa/10;
 }//Calculates number of digits.Number is taken in. If equal to 0, returns 1, otherwise, number of digits iterates as it is cut down from the right (a=a/10) 
 return digits;
}
char* charfrominteger(int a){
 int copyofa2=a;
 int digit=0;
 digit=finddigit(a);
 char* charrarray;
 char holderarray[digit];
 charrarray=(char*)malloc(digit);
 int index=0;//Creates a character array from an integer. Number is taken in. Digit is found, then two char arrays with size of digit created
 if(copyofa2==0){
  index++;
  holderarray[index]=(copyofa2%10)+'0';  
 }
 else{
  while(copyofa2>0){
   index++;
   holderarray[index]=(copyofa2%10)+'0';
   copyofa2=copyofa2/10;
  } //The Number is reduced from the right and the digits are recorded as their char correspondents in the array         
 }
 int counter;
 for(counter=0;counter<index;counter++){
  charrarray[counter]=holderarray[index-counter]; //the Holderarray sends the chars into the charrarray by reverse and it is returned    
 }
 charrarray[counter]='\0';
 return (char*)charrarray;
}
void printinteger(int a){
 int digit=finddigit(a);
 char* storingarray=charfrominteger(a);
 for(int i=0;i<digit;i++){
  char placeholder=storingarray[i];
  write(STDOUT_FILENO,&placeholder,1);  
 }//Uses the previous functions to find the number's digits and create a char array. then on for loop the array is printed
}
int threadnumber=0;
int buffersize=5;//size of buffer for bufferarray
int readfile=0;
int in=0;
int out=0;// monitors as values are inserted into stack and gradually popped out
int in2=0;
int out2=0;//monitor when the buffer arrays operate in and out for first and second threads, in2 and out2 for second and third threads
int indexofstack=0; //keeps track of "top" of stack
int buffersize2=100; //size of stack
int stackofnumbers[100]; //pseudo-stack made from array
struct indexes{
 int index1;
 int index2;
 int arrayofindex;
};//allows one to store index positions
struct indexes prebufferarray[10];//Stores positions to be retrieved by first buffer array
struct indexes bufferarray[5];//First Buffer Array:Transfers between first and second threads the positions
int bufferarray2[5]={0};//Second Buffer Array: Transfers between second and third threads the local minimums
int array1[11]={0};//Stores indexes;
int minnumberarray[10]={0};//Stores minimum number
int processonedone=0;//determines when the list stops being processed by the code;
int allnumbers[10000]={0}; //where all the number values are stored by the machine
int arraycounter=0;
int currentminimum=10000000000000000000000000;//use large number to compare to local minimums
int ultimateminimum;//stores final minimum
int indexer=0;
pthread_mutex_t locker=PTHREAD_MUTEX_INITIALIZER;//initializes mutex to be used. It is global so functions are aware what to use
void *findindexes(void *buffer1){//producer function first processes list then pumps numbers to stack
 int reader=readfile;
 while(1){// while true
 char indexbuffer1;
 int currentnumber1=0;
 int counterofnewlines=0;
 int storednumber=0;
 if(processonedone!=1){//process traverses file, creates numbers from characters, and stores in global array
  while(pread(reader,&indexbuffer1,1,currentnumber1)==1){//while reading through list
   pread(reader,&indexbuffer1,1,currentnumber1);   
   if(indexbuffer1!='\n'){
    if(indexbuffer1=='0') storednumber=(storednumber*10)+0;
    else if(indexbuffer1=='1') storednumber=(storednumber*10)+1;
    else if(indexbuffer1=='2') storednumber=(storednumber*10)+2;
    else if(indexbuffer1=='3') storednumber=(storednumber*10)+3;
    else if(indexbuffer1=='4') storednumber=(storednumber*10)+4;
    else if(indexbuffer1=='5') storednumber=(storednumber*10)+5;
    else if(indexbuffer1=='6') storednumber=(storednumber*10)+6;
    else if(indexbuffer1=='7') storednumber=(storednumber*10)+7;
    else if(indexbuffer1=='8') storednumber=(storednumber*10)+8;
    else if(indexbuffer1=='9') storednumber=(storednumber*10)+9;
   } //translates chars into integers, multiplies by 10 old number to add a digit
   else if(indexbuffer1=='\n'){
    allnumbers[counterofnewlines]=storednumber;
    storednumber=0; 
    counterofnewlines++;
   }// when hits a new line, storednumber is placed in array and cleaned out to make way for another number
   currentnumber1++;
   }
   processonedone++;//Array of numbers is filled, no need to do this loop again
  }
  while((in+1)%5==out){
   sched_yield();
  }//ends thread activity if in+1 modulo buffer size hits out
   indexer=arraycounter;
  if(pthread_mutex_lock(&locker)!=0) return 0;
   stackofnumbers[indexofstack++]=allnumbers[arraycounter];
  if(pthread_mutex_unlock(&locker)!=0) return 0; //pushes array of numbers value onto stack
  arraycounter++; //iterates array value so stack will eventually get next value in array of numbers
   if(arraycounter==10000){
    in=(in+1)%5;   
    break; // breaks loop when all values in array of numbers are processed
   }
   in=(in+1)%5;
}
 return NULL;
};
int currentmin3=10000000000000000;
int counterofints=0;
int localminindex=0;
void *findultimateminimum(void *buffer3){
 while(1){    
  while(in==out){ //if in and out are equal, thread doesn't work
   sched_yield();
  }
 if(pthread_mutex_lock(&locker)!=0) return 0;
  int currentmin2=stackofnumbers[--indexofstack]; //pops from stack
 if(pthread_mutex_unlock(&locker)!=0) return 0;
  out=(out+1)%5; //out iterates
  if(currentmin2<currentminimum) currentminimum=currentmin2;//checks if current global minimum is less than stored value
  if(currentmin2<currentmin3) currentmin3=currentmin2; //checks if current local min is less than stored value
  counterofints++;
  if(counterofints%1000==0){// hits 1000 integers prints current global and local min
   write(STDOUT_FILENO,"Local Minimum after Integers: ",32);
   printinteger(counterofints);
   write(STDOUT_FILENO,": ",2);
   printinteger(currentmin3);
   write(STDOUT_FILENO,"\nGlobal Minimum: ",18);
   printinteger(currentminimum); 
   write(STDOUT_FILENO,"\n Pending \n",11);
   fsync(STDOUT_FILENO);
   currentmin3=10000000000000000;
  }
  if(counterofints==10000){//If all local minimums have been processed, print ultimateminimum
   ultimateminimum=currentminimum;      
   write(STDOUT_FILENO,"Ultimate Minimum: ",18);
   printinteger(ultimateminimum);
   write(STDOUT_FILENO,"\n End \n",7);
   fsync(STDOUT_FILENO);
   break;
  }
 } 
  return NULL;
}
int main(int argc, char const *argv[]){
 int tester1=open(argv[1],O_RDONLY);//Open and test file
 write(STDOUT_FILENO,"Testing pread\n",14);
 if(tester1==-1){
  write(STDOUT_FILENO,"Not working",11);
  return 0;
 }
 write(STDOUT_FILENO,"Tester worked\n",14);
 readfile=tester1; //file number sent to global variable
 pthread_mutex_init(&locker, NULL);
 pthread_t calcthreads[2]; //pthread arrays created, each doing a unique function
 for(int i=0;i<2;i++){
  if(i==0) pthread_create(&calcthreads[i],NULL,findindexes,NULL);
  else if(i==1) pthread_create(&calcthreads[i],NULL,findultimateminimum,NULL);
 }
 for(int i=0;i<2;i++){
  pthread_join(calcthreads[i],NULL);
 }//shut down threads, close, and return
 close(tester1); 
 fsync(STDOUT_FILENO);
 return 0;
}
