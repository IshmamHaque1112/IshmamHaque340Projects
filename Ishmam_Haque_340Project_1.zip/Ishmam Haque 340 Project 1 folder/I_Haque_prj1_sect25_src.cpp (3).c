   //Ishmam Haque Section 25//
   //g++ I_Haque_prj1_sect25_src.cpp -o I_Haque_prj1_sect25_src.exe ./file1.txt>file3.txt //
   #include <stdio.h>
   #include <unistd.h>
   #include <stdlib.h>
   #include <fcntl.h>
   #include <sys/stat.h>
   int finddigit(int a){
      int copyofa=a;
      if(a==0) return 1;
      int digits=0;
      while(copyofa>0){
       digits++;
       copyofa=copyofa/10;
      }
      return digits;
   } //Processes the digits of an integer. Returns 1 if it is 0, otherwise, iterates counter as it is slashed by 10, then returns;//
   char* charfrominteger(int a){
    int copyofa=a;
    int copyofa2=a;
    int digit=0;
    digit=finddigit(a);
    char* charrarray;
    char holderarray[digit];
    charrarray=(char*)malloc(digit);
    int index=0;
    if(copyofa2==0){
     index++;
     holderarray[index]=(copyofa2%10)+'0';
    }
    else{
     while(copyofa2>0){
      index++;
      holderarray[index] =(copyofa2%10)+'0';
      copyofa2=copyofa2/10;
     }
    }
    int counter;
    for(counter=0;counter<index;counter++) {
     charrarray[counter]=holderarray[index-counter];
    }
    charrarray[counter]='\0';
    return (char*)charrarray;
   }//Transforms integer into character array. First finds digits, then for each digit convert to char, which is added to one array, and the array elements are iterated onto another;//
   void printinteger(int a,int b){
     int digit=finddigit(a);
     char* storingarray=charfrominteger(a);
     for(int i=0;i<digit;i++){
      char placeholder=storingarray[i];
      write(STDOUT_FILENO,&placeholder,1);
      write(b,&placeholder,1);
    }//Writes integer into file by first finding integer digits, then calling character array to print the character array of the number integer digit times;// 
   }
   int main(int argc,const char** argv[]){
    int index1=0;
    int index2=0;
    int index3=0;
    int index4=0;
    int newfile1=open("file1.txt",O_RDWR);
    int newfile2=open("file2.txt",O_RDWR);
    int newfile3=open("file3.txt",O_RDWR);
    char indexbuff1;
    char indexbuff2;
    char indexbuff3;
    char indexbuff4;
    int samechar=0;
    int samechar2=0;
    int diffchar=0;
    int diffchar2=0;
    //setting up all pointers and files necessary for this program;//
    if(newfile1==-1){
     write(STDOUT_FILENO,"Oops",4);
     exit(1);
    }
    if(newfile2==-1){
     write(STDOUT_FILENO,"Oops 2",6);
     exit(1);
    }
    if(newfile3==-1){
     write(STDOUT_FILENO,"Oops 3",3);     
     exit(1);
    }
    //if file fails to open, say oops;
    write(STDOUT_FILENO,"File 1 \n",9);
    write(newfile3,"File 1 \n",9);
    index2=lseek(newfile1,-1,SEEK_END);
    index1=lseek(newfile1,0,SEEK_SET);
    //set default indexes to -1 offset for the end of file for end pointer, offset 0 for beginning of file for beginning pointer;//
    while(read(newfile1,&indexbuff1,1)==1){
      char newchar1=indexbuff1;
      lseek(newfile1,index2,SEEK_SET);
      read(newfile1,&indexbuff2,1);
      char newchar2=indexbuff2;
      if(newchar2==newchar1){
       write(STDOUT_FILENO,"0",1);
       write(newfile3,"0",1);
       samechar++;
      }
      else{
          write(STDOUT_FILENO,"1",1);
          write(newfile3,"1",1);
          diffchar++;
      }  
      index1++;
      index2--;
      lseek(newfile1,index1,SEEK_SET);
    }//While text is reading, store beginning index buff, then set pointer to end index and store end buff, compare and print to output file. Then iterate beginning index, decrease end index, then lseek to beginning index;//
    write(STDOUT_FILENO,"\nSame characters 1: ",21);
    write(newfile3,"\nSame characters 1: ",21);
    printinteger(samechar,newfile3);
    write(STDOUT_FILENO,"\nDifferent characters 1: ",26);
    write(newfile3,"\nDifferent characters 1: ",26);
    printinteger(diffchar,newfile3);
    write(STDOUT_FILENO,"\n",2);
    write(newfile3,"\n",2);
    index2=lseek(newfile1,-1,SEEK_END);
    index1=lseek(newfile1,0,SEEK_SET);
    while(read(newfile1,&indexbuff1,1)==1){
      char newchar1=indexbuff1;
      lseek(newfile1,index2,SEEK_SET);
      read(newfile1,&indexbuff2,1);
      char newchar2=indexbuff2;
      if(newchar2!=newchar1){
       write(STDOUT_FILENO,"Different character: ",21);
       write(newfile3,"Different character: ",21);
       printinteger(index1,newfile3);
       write(STDOUT_FILENO," ",1);
       write(newfile3," ",1);
       write(STDOUT_FILENO,&newchar1,1);
       write(newfile3,&newchar1,1);
       write(STDOUT_FILENO," ",1);
       write(newfile3," ",1);
       write(STDOUT_FILENO,&newchar2,1);
       write(newfile3,&newchar2,1);
       write(STDOUT_FILENO,"\n",2);
       write(newfile3,"\n",2);
      }
      index1++;
      index2--;
      lseek(newfile1,index1,SEEK_SET);
    }// Repeat same loop as before, but this time, count which are same and which are not, and if there are different char iterate and print them and the index;//
    write(STDOUT_FILENO,"The amount of numbers that differ is ",37);
    write(newfile3,"The amount of numbers that differ is ",37);
    printinteger(diffchar,newfile3);
    write(STDOUT_FILENO,"\n",2);   
    write(newfile3,"\n",2);
    write(STDOUT_FILENO,"File 2 \n",9);
    write(newfile3,"File 2 \n",9);
    index4=lseek(newfile2,-1,SEEK_END);
    index3=lseek(newfile2,0,SEEK_SET);
    while(read(newfile2,&indexbuff3,1)==1){
      char newchar1=indexbuff3;
      lseek(newfile2,index4,SEEK_SET);
      read(newfile2,&indexbuff4,1);
      char newchar2=indexbuff4;
      if(newchar2==newchar1){
       write(STDOUT_FILENO,"0",1);
       write(newfile3,"0",1);
       samechar2++;
      }
      else{
          write(STDOUT_FILENO,"1",1);
          write(newfile3,"1",1);
          diffchar2++;
      }  
      index3++;
      index4--;
      lseek(newfile2,index3,SEEK_SET);
    }
    write(STDOUT_FILENO,"\nSame characters 2: ",21);
    write(newfile3,"\nSame characters 2: ",21);
    printinteger(samechar2,newfile3);
    write(STDOUT_FILENO,"\nDifferent characters 2: ",26);
    write(newfile3,"\nDifferent characters 2: ",26);
    printinteger(diffchar2,newfile3);
    write(STDOUT_FILENO,"\n",2);   
    write(newfile3,"\n",2);
    index4=lseek(newfile2,-1,SEEK_END);
    index3=lseek(newfile2,0,SEEK_SET);
    while(read(newfile2,&indexbuff3,1)==1){
      char newchar1=indexbuff3;
      lseek(newfile2,index4,SEEK_SET);
      read(newfile2,&indexbuff4,1);
      char newchar2=indexbuff4;
      if(newchar1!=newchar2){
       write(STDOUT_FILENO,"Different character: ",21);
       write(newfile3,"Different character: ",21);
       printinteger(index3,newfile3);
       write(STDOUT_FILENO," ",1);
       write(newfile3," ",1);
       write(STDOUT_FILENO,&newchar1,1);
       write(newfile3,&newchar1,1);
       write(STDOUT_FILENO," ",1);
       write(newfile3," ",1);
       write(STDOUT_FILENO,&newchar2,1);
       write(newfile3,&newchar2,1);
       write(STDOUT_FILENO,"\n",2);
       write(newfile3,"\n",2);
      }
      index3++;
      index4--;
      lseek(newfile2,index3,SEEK_SET);
    }// Repeat what I did for the first file, but this time, to the second file.;//
    write(STDOUT_FILENO,"The amount of numbers that differ is ",37);
    write(newfile3,"The amount of numbers that differ is ",37);
    printinteger(diffchar2,newfile3);
    close(newfile1);
    close(newfile2);
    return 0;
   } 