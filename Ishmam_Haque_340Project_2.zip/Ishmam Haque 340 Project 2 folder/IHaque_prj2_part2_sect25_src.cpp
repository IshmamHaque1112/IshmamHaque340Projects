//Ishmam Haque Tuesday Thursday class
// type ./run.sh command to run file, but edit program file name before typing command. File Composition is as follows
//#/bin/sh
//clear
//g++ -pthread -o test IHaque_prj2_part2_sect25_src.cpp
//if [ -f "test" ]; then
// ./test prj2inp1.txt
// ./test prj2inp2.txt
// rm test
//fi
//Initially my code ran on executable files, but now I will resubmit with the commands from the executables transcribed.
//chmod u+x IHaque_prj2_part2_sect25_src.cpp
//g++ -pthread -o test IHaque_prj2_part2_sect25_src.cpp
//./test prj2inp1.txt
//./test prj2inp2.txt
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdlib.h>
int finddigit(int a){
 int copyofa=a;
 if(a==0) return 1;
 int digits=0;
 while(copyofa>0){
  digits++;
  copyofa=copyofa/10;
 }//Calculates number of digits.Number is taken in. If equal to 0, returns 1, otherwise, number of digits iterates as it is cut down from the right (a=a/10) 
 return digits;
}
char* charfrominteger(int a){
 int copyofa2=a;
 int digit=0;
 digit=finddigit(a);
 char* charrarray;
 char holderarray[digit];
 charrarray=(char*)malloc(digit);
 int index=0;//Creates a character array from an integer. Number is taken in. Digit is found, then two char arrays with size of digit created
 if(copyofa2==0){
  index++;
  holderarray[index]=(copyofa2%10)+'0';  
 }
 else{
  while(copyofa2>0){
   index++;
   holderarray[index]=(copyofa2%10)+'0';
   copyofa2=copyofa2/10;
  } //The Number is reduced from the right and the digits are recorded as their char correspondents in the array         
 }
 int counter;
 for(counter=0;counter<index;counter++){
  charrarray[counter]=holderarray[index-counter]; //the Holderarray sends the chars into the charrarray by reverse and it is returned    
 }
 charrarray[counter]='\0';
 return (char*)charrarray;
}
void printinteger(int a){
 int digit=finddigit(a);
 char* storingarray=charfrominteger(a);
 for(int i=0;i<digit;i++){
  char placeholder=storingarray[i];
  write(STDOUT_FILENO,&placeholder,1);  
 }//Uses the previous functions to find the number's digits and create a char array. then on for loop the array is printed
}
int threadnumber=0;
int buffersize=5;//size of buffer for bufferarray
int readfile=0;
int in=0;
int out=0;
int in2=0;
int out2=0;//monitor when the buffer arrays operate in and out for first and second threads, in2 and out2 for second and third threads
struct indexes{
 int index1;
 int index2;
 int arrayofindex;
};//allows one to store index positions
struct indexes prebufferarray[10];//Stores positions to be retrieved by first buffer array
struct indexes bufferarray[5];//First Buffer Array:Transfers between first and second threads the positions
int bufferarray2[5]={0};//Second Buffer Array: Transfers between second and third threads the local minimums
int array1[11]={0};//Stores indexes;
int minnumberarray[10]={0};//Stores minimum number
int truth=1;
int processonedone=0;
int processonecounter=0;
int processtwocounter=0;
int processthreecounter=0;
int currentminimum=10000000000000000000000000;//use large number to compare to local minimums
int ultimateminimum;//stores final minimum
int minimum(int startoffset, int endoffset){
 int counter2=0;
 int storednumber=0;
 int currentnumber2=startoffset;
 char indexbuffer2;
 int smallarray[1000]={0};
 while(currentnumber2<=endoffset){//from beginning to end index, number characters are used to create a number, shifting to the left each time a new number char is found
  pread(readfile,&indexbuffer2,1,currentnumber2);
  if(indexbuffer2!='\n'){
     if(indexbuffer2=='0') storednumber=(storednumber*10)+0;
     else if(indexbuffer2=='1') storednumber=(storednumber*10)+1;
     else if(indexbuffer2=='2') storednumber=(storednumber*10)+2;
     else if(indexbuffer2=='3') storednumber=(storednumber*10)+3;
     else if(indexbuffer2=='4') storednumber=(storednumber*10)+4;
     else if(indexbuffer2=='5') storednumber=(storednumber*10)+5;
     else if(indexbuffer2=='6') storednumber=(storednumber*10)+6;
     else if(indexbuffer2=='7') storednumber=(storednumber*10)+7;
     else if(indexbuffer2=='8') storednumber=(storednumber*10)+8;
     else if(indexbuffer2=='9') storednumber=(storednumber*10)+9;
  }
  else if(indexbuffer2=='\n'){//If new line character is found, storednumber is put in 1000 element array, and 1000 element array pointer iterates
    if(currentnumber2!=startoffset){  
     smallarray[counter2]=storednumber;
     storednumber=0;
     counter2++;
    }
  }
  currentnumber2++;
 }
 int counter1=smallarray[0];
 for(int i=0;i<1000;i++){
  if(smallarray[i]<counter1) counter1=smallarray[i];    
 }//traverses to find minimum in 1000 element array
 return counter1;
}
void *findindexes(void *buffer1){
 int reader=readfile;
 while(1){// while true
 int boundaryindex=0;
 char indexbuffer1;
 int currentnumber1=0;
 int counterofnewlines=0;
 if(processonedone!=1){//process traverses file, finds total number of lines and gets start and end indexes
  while(pread(reader,&indexbuffer1,1,currentnumber1)==1){
   pread(reader,&indexbuffer1,1,currentnumber1);   
   if(indexbuffer1=='\n') counterofnewlines++;
   if((currentnumber1==0)||((indexbuffer1=='\n')&& counterofnewlines%1000==0)){
    array1[boundaryindex]=currentnumber1;
    boundaryindex++;
   }
   currentnumber1++;
  }
  for(int i=0;i<10;i++){
     prebufferarray[i].index1=array1[i];
     prebufferarray[i].index2=array1[i+1];
     prebufferarray[i].arrayofindex=i;
  }//stores found indexes in structarray
  processonedone++;
 }
  write(STDOUT_FILENO,"Array ",6);
  printinteger(processonecounter);
  write(STDOUT_FILENO," Start: ",8);
  printinteger(prebufferarray[processonecounter].index1);
  write(STDOUT_FILENO," End: ",6);
  printinteger(prebufferarray[processonecounter].index2);
  write(STDOUT_FILENO,"\n",1);
  fsync(STDOUT_FILENO);//prints start end index
  while(((in+1)%5)==out){
   sched_yield();
  }//ends thread activity if in+1 modulo buffer size hits out
   bufferarray[in]=prebufferarray[processonecounter]; //A start and end index is stored in buffer array
   processonecounter++;
   if(processonecounter==10){
      in=(in+1)%5;
      break;
   }//If  all the 10 starts and ends are sent to buffer array, break loop
   in=(in+1)%5; // in iterates
 }
 return NULL;
}
void *findlocalminimum(void *buffer2){
 while(1){    
  while(in==out){//if in and out are equal, thread doesn't work
     sched_yield();
  }    
  struct indexes cookie=bufferarray[out]; //struct retrieved from bufferarray
  out=(out+1)%5;//out is iterated
  int currentmin=minimum(cookie.index1,cookie.index2);
  minnumberarray[cookie.arrayofindex]=minimum(cookie.index1,cookie.index2); //local minimum from first bufferarray
  write(STDOUT_FILENO,"\n For Array ",12);
  printinteger(cookie.arrayofindex);
  write(STDOUT_FILENO," Local Minimum Is ",18);
  printinteger(currentmin); 
  write(STDOUT_FILENO,"\n",1); //prints
  while((in2+1)%5==out2){ //ends thread activity if in2+1 modulo buffer size hits out2
   sched_yield();
  }
  bufferarray2[in2]=minimum(cookie.index1,cookie.index2); //local minimum from first bufferarray stored on second buffer array
  processtwocounter++;
  if(processtwocounter==10){
    in2=(in2+1)%5;
    break;
  }
  in2=(in2+1)%5; //in2 iterates
 } 
 return NULL;
}
void *findultimateminimum(void *buffer3){
 while(1){    
  while(in2==out2){ //if in2 and out2 are equal, thread doesn't work
   sched_yield();
  }
  int currentmin2=bufferarray2[out2];
  out2=(out2+1)%5;
  if(currentmin2<currentminimum) currentminimum=currentmin2;//checks if global minimum is less than minimum from second buffer
  processthreecounter++;
  if(processthreecounter==10){//If all local minimums have been processed, print ultimateminimum
   ultimateminimum=currentminimum;      
   write(STDOUT_FILENO,"Ultimate Minimum: ",18);
   printinteger(ultimateminimum);
   write(STDOUT_FILENO,"\n End \n",7);
   fsync(STDOUT_FILENO);
   break;
  }
 } 
  return NULL;
}
int main(int argc, char const *argv[]){
 int tester1=open(argv[1],O_RDONLY);//Open and test file
 write(STDOUT_FILENO,"Testing pread\n",14);
 if(tester1==-1){
  write(STDOUT_FILENO,"Not working",11);
  return 0;
 }
 write(STDOUT_FILENO,"Tester worked\n",14);
 readfile=tester1; //file number sent to global variable
 pthread_t calcthreads[3]; //pthread arrays created, each doing a unique function
 for(int i=0;i<3;i++){
  if(i==0) pthread_create(&calcthreads[i],NULL,findindexes,NULL);
  else if(i==1) pthread_create(&calcthreads[i],NULL,findlocalminimum,NULL);
  else if(i==2) pthread_create(&calcthreads[i],NULL,findultimateminimum,NULL);
 }
 for(int i=0;i<3;i++){
  pthread_join(calcthreads[i],NULL);
 }//shut down threads, close, and return
 close(tester1); 
 fsync(STDOUT_FILENO);
 return 0;
}
