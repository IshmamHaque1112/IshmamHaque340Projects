//Ishmam Haque Tuesday and Thursday class
//If one desires to output, the ./run.sh command will work, but edit file Composition of ./run.sh is follows
//#/bin/sh
//clear
//g++ -pthread -o test IHaque_prj2_part1_sect25_src.cpp
//if [ -f "test" ]; then
// ./test prj2inp1.txt
// ./test prj2inp2.txt
// rm test
//fi
//Initially my code ran on executable files, but now I will resubmit with the commands from the executables transcribed.
//chmod u+x IHaque_prj2_part1_sect25_src.cpp
//g++ -pthread -o test IHaque_prj2_part1_sect25_src.cpp
//./test prj2inp1.txt
//./test prj2inp2.txt
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdlib.h>
int finddigit(int a){
 int copyofa=a;
 if(a==0) return 1;
 int digits=0;
 while(copyofa>0){
  digits++; 
  copyofa=copyofa/10;
 }
 return digits;//This function returns the digit in a number. If the number is 0, it returns 1, but if it doesn't, the too-be returned value iterates, and for each iteration, a copy of the number loses a digit.
}
char* charfrominteger(int a){
 int copyofa2=a;
 int digit=0;
 digit=finddigit(a);
 char* charrarray;
 char holderarray[digit];
 charrarray=(char*)malloc(digit);// This function converts an integer to a character array. Charrarray holds the to be returned values. First the digits of the enterednumber are found and used to make a holderarray.
 int index=0;
 if(copyofa2==0){
  index++;
  holderarray[index]=(copyofa2%10)+'0';  
 }// The holderarray is used to store the elements, converting digits into chars
 else{
  while(copyofa2>0){
   index++;
   holderarray[index]=(copyofa2%10)+'0';
   copyofa2=copyofa2/10;
  } //The number is cut down and the digits are read in reverse into the holderarray.
 }
 int counter;
 for(counter=0;counter<index;counter++){
  charrarray[counter]=holderarray[index-counter];   
 }//The holderarray sends the elements into the charrarray in reverse, as the holderarray cut down the input number digit by digit from the right
 charrarray[counter]='\0';
 return (char*)charrarray;
}
void printinteger(int a){
 int digit=finddigit(a);
 char* storingarray=charfrominteger(a);
 for(int i=0;i<digit;i++){
  char placeholder=storingarray[i];
  write(STDOUT_FILENO,&placeholder,1);  
 }
}//The integer is converted into a character array, then said array is written digit by digit
int threadnumber=0;
int minnumberarray[10]={0};
int allarray[10000]={0};
int array1[11]={0};//Arrays for minimums, unused array for all, and array to hold indexes
struct numberthread{
 int indexstart;
 int indexend;
 int threadnumber;
 int minimumnumber;
 int filetoread; 
}// This struct stands for each of the 10 number threads, holding start, end indexes, thread number, the minimum, and the file it is read from
;
void *minimum(void *abc){
 struct numberthread *cookie=(struct numberthread *)abc;
 int startoffset=cookie->indexstart;
 int endoffset=cookie->indexend;
 int threadnum=cookie->threadnumber;
 int fileread=cookie->filetoread;
 int counter2=0;//The numberthread is stored to be used to calculate minimum of a 1000 element array
 int storednumber=0;
 int currentnumber2=startoffset;
 char indexbuffer2;
 int smallarray[1000]={0};
 while(currentnumber2<=endoffset){//The file is read from given beginning to given end offsets
  pread(fileread,&indexbuffer2,1,currentnumber2);
  if(indexbuffer2!='\n'){
     if(indexbuffer2=='0') storednumber=(storednumber*10)+0;
     else if(indexbuffer2=='1') storednumber=(storednumber*10)+1;
     else if(indexbuffer2=='2') storednumber=(storednumber*10)+2;
     else if(indexbuffer2=='3') storednumber=(storednumber*10)+3;
     else if(indexbuffer2=='4') storednumber=(storednumber*10)+4;
     else if(indexbuffer2=='5') storednumber=(storednumber*10)+5;
     else if(indexbuffer2=='6') storednumber=(storednumber*10)+6;
     else if(indexbuffer2=='7') storednumber=(storednumber*10)+7;
     else if(indexbuffer2=='8') storednumber=(storednumber*10)+8;
     else if(indexbuffer2=='9') storednumber=(storednumber*10)+9;
  }//While the element is reading, if char is not a new line, the read char is converted to a digit, then storednumber is multiplied by ten and the digit is added on, basically adding a new digit, working to assemble a number 
  else if(indexbuffer2=='\n'){
    if(currentnumber2!=startoffset){  
     smallarray[counter2]=storednumber; //if the char hits a new line, the storednumber is put in the array, and storednumber goes back to zero
     storednumber=0;
     counter2++;
    }
  }
  currentnumber2++;
 }
 int counter1=smallarray[0];
 for(int i=0;i<1000;i++){
  if(smallarray[i]<counter1) counter1=smallarray[i];    
 } //sort to find min of 1000 element array
 minnumberarray[threadnum]=counter1;
 write(STDOUT_FILENO,"\tThread \t",9);
 printinteger(threadnum);
 write(STDOUT_FILENO,"\tStart: \t",9);
 printinteger(startoffset);
 write(STDOUT_FILENO,"\tEnd: \t",7);
 printinteger(endoffset);
 write(STDOUT_FILENO,"\tLocal min:\t",12);
 printinteger(counter1);
 write(STDOUT_FILENO,"\t Thread done \n",15);
 fsync(STDOUT_FILENO);
 return NULL;//print out and exit
}
int main(int argc, char const *argv[]){
 char* buffer1;
 char indexbuffer1;
 int tester1=open(argv[1],O_RDONLY);
 write(STDOUT_FILENO,"Testing pread\n",14);
 if(tester1==-1){
  write(STDOUT_FILENO,"Not working",11);
  return 0;//test if can be read
 }
 write(STDOUT_FILENO,"Tester worked\n",14);
 int boundaryindex=0;
 int currentnumber1=0;
 int counterofnewlines=0;
 while(pread(tester1,&indexbuffer1,1,currentnumber1)==1){
  pread(tester1,&indexbuffer1,1,currentnumber1);   
  if(indexbuffer1=='\n') counterofnewlines++;
  if((currentnumber1==0)||((indexbuffer1=='\n')&& counterofnewlines%1000==0)){
   array1[boundaryindex]=currentnumber1;
   boundaryindex++;//Finds how many new lines there are, and determines indexes to be used to make ten element array
  }
  currentnumber1++;
 }
 struct numberthread datathreads[10];
 for(int i=0;i<10;i++){
  datathreads[i].indexstart=array1[i];
  datathreads[i].indexend=array1[i+1];
  datathreads[i].threadnumber=i;
  datathreads[i].filetoread=tester1;  
 }//sets up numberthreads to be processed by pthreads
 pthread_t pthreads[10];
 for(int i=0;i<10;i++){
  pthread_create(&pthreads[i],NULL,minimum,(void*)&datathreads[i]);
 }//the pthreads are created and process the 10 subsections of the file, finding 10 local minimums, then are joined together
 for(int i=0;i<10;i++){
  pthread_join(pthreads[i],NULL);
 }
 for(int i=0;i<10;i++){
  write(STDOUT_FILENO,"\n For Array ",12);
  printinteger(i);
  write(STDOUT_FILENO," Local Minimum Is ",18);
  printinteger(minnumberarray[i]); 
  write(STDOUT_FILENO,"\n",1);  
 }
 int ultimateminimum=minnumberarray[0];
 for(int i=0;i<10;i++){
  if(ultimateminimum>minnumberarray[i]) ultimateminimum=minnumberarray[i];
 }//The local minimums are printed again, and the array is sorted to find the smallest element
 write(STDOUT_FILENO,"Ultimate Minimum: ",18);
 printinteger(ultimateminimum);
 write(STDOUT_FILENO,"\n End \n",7);
 close(tester1); 
 fsync(STDOUT_FILENO);
 return 0;
}
